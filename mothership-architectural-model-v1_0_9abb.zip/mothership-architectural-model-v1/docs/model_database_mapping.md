# Model ↔ database mapping

The database is the asset register of record for this concept model. Stable `element_id` values map geometry names in Blender and OpenSCAD object labels. IFC GlobalIds are nullable until generated and reconciled by the IFC export workflow.

| Database table | Architectural meaning |
|---|---|
| buildings | Mothership and four Fleet Capsule structures |
| floors | Storeys / floor plates |
| rooms | Spaces and functional zones |
| model_elements | Geometry-linked model objects |
| components | Installed or planned equipment |
| connections | Docking, power, data, WAN and service relationships |
| geolocation | GNSS coordinates and source metadata |
| model_views | Assembly, cutaway and exploded presentation sets |

Example queries:
```sql
SELECT b.name, COUNT(e.element_id) AS modeled_elements
FROM buildings b LEFT JOIN model_elements e USING(building_id)
GROUP BY b.building_id;

SELECT e.element_id,e.name,c.subsystem,c.status
FROM model_elements e LEFT JOIN components c USING(element_id)
ORDER BY e.element_id;

SELECT * FROM connections;
```
