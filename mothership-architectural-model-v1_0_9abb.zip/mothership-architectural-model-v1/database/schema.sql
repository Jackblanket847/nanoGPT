PRAGMA foreign_keys=ON;
CREATE TABLE IF NOT EXISTS buildings(
 building_id TEXT PRIMARY KEY, name TEXT NOT NULL, building_type TEXT NOT NULL,
 description TEXT, model_file TEXT, created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS floors(
 floor_id TEXT PRIMARY KEY, building_id TEXT NOT NULL REFERENCES buildings(building_id),
 level_no INTEGER NOT NULL, name TEXT NOT NULL, elevation_mm REAL NOT NULL,
 UNIQUE(building_id,level_no)
);
CREATE TABLE IF NOT EXISTS rooms(
 room_id TEXT PRIMARY KEY, floor_id TEXT NOT NULL REFERENCES floors(floor_id),
 name TEXT NOT NULL, room_type TEXT NOT NULL, area_m2 REAL, notes TEXT
);
CREATE TABLE IF NOT EXISTS model_elements(
 element_id TEXT PRIMARY KEY, building_id TEXT NOT NULL REFERENCES buildings(building_id),
 floor_id TEXT REFERENCES floors(floor_id), room_id TEXT REFERENCES rooms(room_id),
 category TEXT NOT NULL, name TEXT NOT NULL, model_object_name TEXT,
 ifc_global_id TEXT, x_mm REAL, y_mm REAL, z_mm REAL,
 width_mm REAL, depth_mm REAL, height_mm REAL, properties_json TEXT DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS components(
 component_id TEXT PRIMARY KEY, element_id TEXT NOT NULL REFERENCES model_elements(element_id),
 subsystem TEXT NOT NULL, manufacturer TEXT, part_number TEXT, status TEXT DEFAULT 'concept',
 properties_json TEXT DEFAULT '{}'
);
CREATE TABLE IF NOT EXISTS connections(
 connection_id TEXT PRIMARY KEY, from_element_id TEXT NOT NULL REFERENCES model_elements(element_id),
 to_element_id TEXT NOT NULL REFERENCES model_elements(element_id),
 connection_type TEXT NOT NULL, description TEXT
);
CREATE TABLE IF NOT EXISTS geolocation(
 geo_id TEXT PRIMARY KEY, building_id TEXT NOT NULL REFERENCES buildings(building_id),
 latitude REAL, longitude REAL, accuracy_m REAL, source TEXT DEFAULT 'not_configured',
 recorded_at TEXT
);
CREATE TABLE IF NOT EXISTS model_views(
 view_id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT, blender_collection TEXT
);
CREATE INDEX IF NOT EXISTS idx_floors_building ON floors(building_id);
CREATE INDEX IF NOT EXISTS idx_rooms_floor ON rooms(floor_id);
CREATE INDEX IF NOT EXISTS idx_elements_building ON model_elements(building_id);
CREATE INDEX IF NOT EXISTS idx_elements_floor ON model_elements(floor_id);
CREATE INDEX IF NOT EXISTS idx_elements_room ON model_elements(room_id);
CREATE INDEX IF NOT EXISTS idx_elements_category ON model_elements(category);
CREATE INDEX IF NOT EXISTS idx_components_element ON components(element_id);
CREATE INDEX IF NOT EXISTS idx_components_subsystem ON components(subsystem);
CREATE INDEX IF NOT EXISTS idx_connections_from ON connections(from_element_id);
CREATE INDEX IF NOT EXISTS idx_connections_to ON connections(to_element_id);
CREATE INDEX IF NOT EXISTS idx_geolocation_building ON geolocation(building_id);
