from pathlib import Path
import sqlite3, json
HERE=Path(__file__).resolve().parent
DB=HERE/"mothership_building.sqlite"
schema=(HERE/"schema.sql").read_text()
if DB.exists(): DB.unlink()
c=sqlite3.connect(DB); c.executescript(schema)
buildings=[("BLD-001","Mothership BaseStation","central_hub","Central command, networking and docking building","blender/build_scene.py")]
for i in range(1,5):
    buildings.append((f"FLT-00{i}",f"Fleet Capsule {i}","detachable_capsule",f"Detachable satellite-connected service capsule {i}","blender/build_scene.py"))
c.executemany("INSERT INTO buildings(building_id,name,building_type,description,model_file) VALUES(?,?,?,?,?)",buildings)
floors=[
("FLR-M-01","BLD-001",0,"Lower services",0),("FLR-M-02","BLD-001",1,"Operations level",4200),("FLR-M-03","BLD-001",2,"Upper communications",7800)]
for i in range(1,5):
    floors += [(f"FLR-F{i}-01",f"FLT-00{i}",0,"Capsule service level",0),(f"FLR-F{i}-02",f"FLT-00{i}",1,"Capsule operations level",3000)]
c.executemany("INSERT INTO floors VALUES(?,?,?,?,?)",floors)
rooms=[]
for fid,name,typ in [
("FLR-M-01","Power and UPS Room","electrical"),("FLR-M-01","Network Distribution Room","network"),
("FLR-M-02","Command and Operations","operations"),("FLR-M-02","Fleet Monitoring Room","control"),
("FLR-M-03","Satellite Terminal Room","satellite"),("FLR-M-03","GNSS and Antenna Service","communications")]:
    rooms.append((f"ROOM-{len(rooms)+1:03}",fid,name,typ,80.0,"Concept room; verify code and service clearances"))
for i in range(1,5):
    for fid,name,typ in [(f"FLR-F{i}-01","Power Interface Room","electrical"),(f"FLR-F{i}-01","Router and Backhaul Room","network"),(f"FLR-F{i}-02","Basestation and Service Room","communications")]:
        rooms.append((f"ROOM-{len(rooms)+1:03}",fid,name,typ,28.0,"Concept room"))
c.executemany("INSERT INTO rooms VALUES(?,?,?,?,?,?)",rooms)
elements=[]
def add(eid,bid,cat,name,obj,x,y,z,w,d,h,floor=None,room=None,props=None):
    elements.append((eid,bid,floor,room,cat,name,obj,None,x,y,z,w,d,h,json.dumps(props or {})))
add("EL-M-CORE","BLD-001","building_core","Central Mothership Core","Mothership_Core",0,0,0,26000,26000,9000,"FLR-M-02",None,{"shape":"circular"})
add("EL-M-DOCK-1","BLD-001","docking_bay","Docking Bay 1","Dock_Bay_1",18000,0,0,5000,9800,5600)
for i,(x,y) in enumerate([(30000,0),(0,30000),(-30000,0),(0,-30000)],1):
    add(f"EL-F{i}-POD",f"FLT-00{i}","capsule_shell",f"Fleet Capsule {i} Shell",f"Fleet_{i}_Capsule",x,y,0,18000,9000,6000,f"FLR-F{i}-01")
    add(f"EL-F{i}-DOCK", "BLD-001","docking_interface",f"Fleet {i} Dock Interface",f"Dock_Interface_{i}",x*0.68,y*0.68,0,5000,9800,5600)
    add(f"EL-F{i}-ROUTER",f"FLT-00{i}","network","Fleet Router",f"Fleet_{i}_Router",x,y,900,700,500,1800,f"FLR-F{i}-01",None,{"role":"WAN/LAN router","internet_path":"via Mothership when docked"})
    add(f"EL-F{i}-AP",f"FLT-00{i}","basestation","Fleet Wireless Basestation",f"Fleet_{i}_AP",x,y,1800,900,500,250,f"FLR-F{i}-02")
for eid,cat,name,obj,x,y,z in [
("EL-M-SAT","satellite","Satellite Terminal","Satellite_Terminal",0,0,6500),
("EL-M-SW","network","Managed Core Switch","Core_Switch",0,0,1000),
("EL-M-PDU","electrical","Protected DC Distribution","DC_PDU",0,0,-1000),
("EL-M-GNSS","geolocation","GNSS Receiver","GNSS_Receiver",0,0,8500)]:
    add(eid,"BLD-001",cat,name,obj,x,y,z,1200,900,500)
c.executemany("""INSERT INTO model_elements(element_id,building_id,floor_id,room_id,category,name,model_object_name,ifc_global_id,x_mm,y_mm,z_mm,width_mm,depth_mm,height_mm,properties_json)
VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",elements)
components=[]
for eid,sub in [("EL-M-SAT","satellite"),("EL-M-SW","network"),("EL-M-PDU","electrical"),("EL-M-GNSS","geolocation")]:
    components.append((f"CMP-{len(components)+1:03}",eid,sub,None,None,"concept","{}"))
for i in range(1,5):
    for suffix,sub in [("ROUTER","network"),("AP","basestation")]:
        components.append((f"CMP-{len(components)+1:03}",f"EL-F{i}-{suffix}",sub,None,None,"concept","{}"))
c.executemany("INSERT INTO components VALUES(?,?,?,?,?,?,?)",components)
connections=[]
for i in range(1,5):
    connections += [(f"CON-{i:02}-P", "EL-M-SW",f"EL-F{i}-ROUTER","ethernet","Isolated fleet VLAN uplink"),
                    (f"CON-{i:02}-D",f"EL-F{i}-POD",f"EL-F{i}-DOCK","mechanical_dock","Keyed removable docking interface")]
connections += [("CON-SAT","EL-M-SAT","EL-M-SW","wan","Satellite WAN path through Mothership gateway")]
c.executemany("INSERT INTO connections VALUES(?,?,?,?,?)",connections)
c.executemany("INSERT INTO geolocation(geo_id,building_id,source) VALUES(?,?,?)",
              [(f"GEO-{i:03}",b,"not_configured") for i,b in enumerate(["BLD-001","FLT-001","FLT-002","FLT-003","FLT-004"],1)])
c.executemany("INSERT INTO model_views VALUES(?,?,?,?)",[
("VIEW-01","Assembly","Complete Mothership and four capsules","01_ASSEMBLY"),
("VIEW-02","Cutaway","Interior floors and rooms exposed","02_CUTAWAY"),
("VIEW-03","Exploded","Pods separated from docking positions","03_EXPLODED")])
c.commit(); print(f"Seeded {DB} with {len(buildings)} buildings, {len(floors)} floors, {len(rooms)} rooms, {len(elements)} elements")
c.close()
