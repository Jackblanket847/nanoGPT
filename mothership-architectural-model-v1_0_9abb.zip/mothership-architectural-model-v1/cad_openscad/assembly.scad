// Four-capsule assembly concept. Units: mm.
include <mothership.scad>;
