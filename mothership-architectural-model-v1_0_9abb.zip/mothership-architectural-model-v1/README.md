# Mothership Spaceship Building + Four Fleet Capsule Models — v1.0

Editable architectural/CAD + BIM project with an integrated, indexed SQLite asset database.

## Deliverables
- OpenSCAD parametric concept models: Mothership, Fleet Capsule, docking bay, assembly.
- Blender Python generator: creates a 3D architectural model with exterior, cutaway, exploded views, floor plates, rooms, docking arms, and infrastructure markers. Run in Blender's scripting workspace or `blender --background --python blender/build_scene.py`.
- IFC generator: creates an IFC4 BIM spatial structure and component inventory using IfcOpenShell. It is source code; install `ifcopenshell` in the Python environment used for the script.
- SQLite database with indexed building/floor/room/element/component/connection/location tables and seeded records.
- SVG schematic drawings and documentation.

## Coordinate convention
All dimensions are millimetres in CAD files. The central Mothership origin is (0,0,0). Fleet pods are arranged at cardinal directions. The model is a terrestrial architectural concept, not an orbital spacecraft or certified building design.

## Build the Blender model
1. Install Blender 4.x.
2. Open `blender/build_scene.py` in Blender's Scripting workspace and Run Script, or run:
   `blender --background --python blender/build_scene.py`
3. The script creates three collections/views: `01_ASSEMBLY`, `02_CUTAWAY`, `03_EXPLODED`.
4. Save as `mothership_fleet_architecture.blend`. The script also attempts to export `.glb` and `.obj` to the project output folder.

## Build the BIM / IFC model
Install IfcOpenShell in a compatible Python environment, then:
`python bim_ifc/build_ifc.py`
The resulting IFC4 file is a conceptual spatial/asset model with project, site, building, storeys, spaces, and physical elements. Validate it in an IFC viewer before using it as a BIM coordination deliverable.

## Database
The SQLite database is `database/mothership_building.sqlite`. The schema is also provided as `database/schema.sql`.
Run `python database/seed_database.py` to recreate and seed it.
Run tests with `python -m unittest discover -s tests -v`.

## Database indexing convention
- BLD-001: Mothership building
- FLT-001..004: Fleet capsule buildings
- FLR-* floors; ROOM-* spaces; DCK-* docking components
- ELE-* electrical; NET-* network; SAT-* satellite; GEO-* geolocation
Each modeled object has a stable `element_id` and optional Blender object name / IFC GlobalId reference. `model_element_id` is the key join between geometry and database.

## Important limits
This is an editable conceptual design model, not a permit-ready architectural set, structural design, life-safety design, electrical construction document, or fabrication package. Dimensions, egress, fire ratings, accessibility, foundations, wind/seismic loads, waterproofing, RF exposure, grounding, and code compliance require qualified local professionals. Satellite coverage/service is provider- and location-specific. GNSS provides positioning, not internet connectivity. No purchase, subscription, deployment, energizing, or radio transmission is performed or authorized.
