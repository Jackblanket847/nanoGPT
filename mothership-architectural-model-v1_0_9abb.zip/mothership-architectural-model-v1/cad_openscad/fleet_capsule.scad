// Fleet capsule building envelope. Units: mm.
$fn=48;
L=18000; W=9000; H=6000; wall=300;
module pod(){ difference(){
  minkowski(){cube([L-600,W-600,H-600],center=true);sphere(r=300);}
  cube([L-2*wall,W-2*wall,H-2*wall],center=true);
}}
pod();
