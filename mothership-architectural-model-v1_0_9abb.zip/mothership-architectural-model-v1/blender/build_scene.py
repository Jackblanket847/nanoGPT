# Blender 4.x scene generator. Run with Blender's embedded Python.
import bpy, math, os
from mathutils import Vector
from pathlib import Path
# Save outputs beside project when run from this script's location.
OUT=Path(__file__).resolve().parents[1]/"generated"
OUT.mkdir(exist_ok=True)
bpy.ops.object.select_all(action='SELECT'); bpy.ops.object.delete(use_global=False)
for c in list(bpy.data.collections):
    if c.name!="Collection": bpy.data.collections.remove(c)
def collection(name):
    c=bpy.data.collections.new(name); bpy.context.scene.collection.children.link(c); return c
assembly=collection("01_ASSEMBLY"); cutaway=collection("02_CUTAWAY"); exploded=collection("03_EXPLODED")
def mat(name,color,metal=0,rough=.4):
    m=bpy.data.materials.new(name); m.diffuse_color=(*color,1); m.metallic=metal; m.roughness=rough; return m
silver=mat("Titanium Ceramic",(0.55,.68,.78),.72,.27); blue=mat("Signal Blue",(.025,.25,.55),.45,.25)
dark=mat("Graphite",(.035,.07,.11),.35,.5); amber=mat("Power Amber",(.95,.42,.06),.2,.35); glass=mat("Glazing",(.02,.25,.36),.6,.12)
def move_to(obj,col):
    for c in list(obj.users_collection): c.objects.unlink(obj)
    col.objects.link(obj); return obj
def cube(name,loc,scale,material,col,bev=0):
    bpy.ops.mesh.primitive_cube_add(size=1, location=loc); o=bpy.context.object; o.name=name; o.dimensions=scale
    bpy.ops.object.transform_apply(location=False,rotation=False,scale=True)
    if material:o.data.materials.append(material)
    if bev:
        mod=o.modifiers.new("Soft architectural edges","BEVEL"); mod.width=bev; mod.segments=3
    return move_to(o,col)
def cyl(name,loc,radius,depth,material,col,vertices=96):
    bpy.ops.mesh.primitive_cylinder_add(vertices=vertices,radius=radius,depth=depth,location=loc)
    o=bpy.context.object;o.name=name
    if material:o.data.materials.append(material)
    return move_to(o,col)
def sphere(name,loc,scale,material,col):
    bpy.ops.mesh.primitive_uv_sphere_add(segments=32,ring_count=16,location=loc);o=bpy.context.object;o.name=name;o.scale=scale
    if material:o.data.materials.append(material)
    return move_to(o,col)
def label(name,text,loc,size,col):
    bpy.ops.object.text_add(location=loc);o=bpy.context.object;o.name=name;o.data.body=text;o.data.size=size;o.data.extrude=2
    o.data.materials.append(blue);return move_to(o,col)
# central building core: scaled to meters for Blender
cyl("Mothership_Core_Foundation",(0,0,0),13,1.2,dark,assembly)
cyl("Mothership_Lower_Level",(0,0,1.2),12,2.4,silver,assembly)
cyl("Mothership_Operations_Level",(0,0,3.5),10.5,2.2,glass,assembly)
cyl("Mothership_Communications_Level",(0,0,5.5),8,1.8,silver,assembly)
cyl("Mothership_Roof_Dome",(0,0,7),5,1.2,blue,assembly)
cyl("Satellite_Radome",(0,0,8.2),2.1,.8,silver,assembly)
# ring architecture
for r,z in [(14,1.1),(11.5,2.6),(9.2,4.7)]:
    bpy.ops.mesh.primitive_torus_add(major_radius=r,minor_radius=.18,major_segments=96,minor_segments=12,location=(0,0,z))
    o=bpy.context.object;o.name=f"Architectural_Ring_{r}";o.data.materials.append(blue);move_to(o,assembly)
# floor plates and room partitions inside core
for z in [.2,2.4,4.6]:
    cyl(f"Floor_Plate_{z}",(0,0,z),9.2,.12,dark,cutaway)
# radial room walls
for z in [.9,3.1,5.3]:
    for a in range(0,360,45):
        rad=math.radians(a)
        cube(f"Room_Partition_{z}_{a}",(5.7*math.cos(rad),5.7*math.sin(rad),z),(6,.12,1.9),silver,cutaway,.04).rotation_euler[2]=rad
# docking arms and bays + fleet pods
positions=[(1,0),(0,1),(-1,0),(0,-1)]
for i,(dx,dy) in enumerate(positions,1):
    angle=math.atan2(dy,dx)
    # arm
    arm=cube(f"Dock_Arm_{i}",(dx*20,dy*20,1.2),(17,3.4,3.0),dark,assembly,.3);arm.rotation_euler[2]=angle
    bay=cube(f"Dock_Bay_{i}",(dx*27,dy*27,1.5),(5,10,6),blue,assembly,.3);bay.rotation_euler[2]=angle
    # pod placement; local length along radial axis
    px,py=dx*35,dy*35
    pod=cube(f"Fleet_{i}_Capsule_Shell",(px,py,1.8),(18,9,6),silver,assembly,.9);pod.rotation_euler[2]=angle
    cube(f"Fleet_{i}_Window_Band",(px,py,3.0),(14,9.1,.55),glass,assembly,.2).rotation_euler[2]=angle
    cube(f"Fleet_{i}_Roof_Antenna",(px,py,5.2),(2,2,.25),amber,assembly,.1)
    label(f"Fleet_{i}_Label",f"FLEET {i}",(px-3,py-5,5.5),1.0,assembly)
    # pod room blocks in cutaway
    cube(f"Fleet_{i}_Power_Room",(px,py-1.8,.9),(5,4,1.6),amber,cutaway,.1)
    cube(f"Fleet_{i}_Network_Room",(px,py+1.8,.9),(5,4,1.6),blue,cutaway,.1)
    # exploded pod copy farther out
    ex,ey=dx*49,dy*49
    e=cube(f"Exploded_Fleet_{i}_Capsule",(ex,ey,2),(18,9,6),silver,exploded,.9);e.rotation_euler[2]=angle
    cube(f"Exploded_Dock_Connector_{i}",(dx*30,dy*30,1.5),(2,2,2),amber,exploded,.1)
label("Mothership_Title","MOTHERSHIP BASESTATION",( -10,-2,10),1.5,assembly)
# scene lighting/camera
world=bpy.context.scene.world
if world: world.color=(.025,.035,.055)
bpy.ops.object.light_add(type='AREA', location=(0,-20,35));bpy.context.object.data.energy=4500;bpy.context.object.data.shape='DISK';bpy.context.object.data.size=25
bpy.ops.object.camera_add(location=(65,-75,65));cam=bpy.context.object;cam.name="Architectural_Overview_Camera"
direction=Vector((0,0,1))-cam.location;cam.rotation_euler=direction.to_track_quat('-Z','Y').to_euler();cam.data.lens=42
scene=bpy.context.scene;scene.camera=cam;scene.render.engine='BLENDER_EEVEE_NEXT'
scene.render.resolution_x=1800;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
# save and export
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/"mothership_fleet_architecture.blend"))
try:
    bpy.ops.export_scene.gltf(filepath=str(OUT/"mothership_fleet_architecture.glb"),export_format='GLB')
except Exception as e: print("GLB export unavailable:",e)
try:
    bpy.ops.wm.obj_export(filepath=str(OUT/"mothership_fleet_architecture.obj"))
except Exception as e: print("OBJ export unavailable:",e)
print("Mothership scene generated:",OUT)
