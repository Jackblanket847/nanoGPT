// Mothership central building concept. Units: mm. Editable parametric envelope.
$fn=64;
core_d=26000; core_h=9000; wing_w=7000; wing_l=16000; pod_count=4;
module cylinder_shell(d,h,t=500){ difference(){cylinder(d=d,h=h,center=true);cylinder(d=d-2*t,h=h+2,center=true);} }
module core(){ cylinder_shell(core_d,core_h); translate([0,0,core_h/2+1800]) cylinder(d=9000,h=3600,center=true); }
module docking_arm(a){ rotate([0,0,a]) translate([core_d/2+wing_l/2-1000,0,0]) cube([wing_l,wing_w,5000],center=true); }
module docking_bay(a){ rotate([0,0,a]) translate([core_d/2+wing_l-1000,0,0]) cube([5000,wing_w+800,5600],center=true); }
core();
for(a=[0:90:270]) { docking_arm(a); docking_bay(a); }
