# Concept IFC4 generator. Requires ifcopenshell installed.
import ifcopenshell, ifcopenshell.api
from pathlib import Path
out=Path(__file__).resolve().parents[1]/"generated";out.mkdir(exist_ok=True)
f=ifcopenshell.api.run("project.create_file",version="IFC4")
project=ifcopenshell.api.run("root.create_entity",f,ifc_class="IfcProject",name="Mothership Fleet Campus")
length=ifcopenshell.api.run("unit.add_si_unit",f,unit_type="LENGTHUNIT")
area=ifcopenshell.api.run("unit.add_si_unit",f,unit_type="AREAUNIT")
volume=ifcopenshell.api.run("unit.add_si_unit",f,unit_type="VOLUMEUNIT")
ifcopenshell.api.run("unit.assign_unit",f,units=[length,area,volume])
model=ifcopenshell.api.run("context.add_context",f,context_type="Model")
body=ifcopenshell.api.run("context.add_context",f,context_type="Model",context_identifier="Body",target_view="MODEL_VIEW",parent=model)
site=ifcopenshell.api.run("root.create_entity",f,ifc_class="IfcSite",name="Mothership Site")
bld=ifcopenshell.api.run("root.create_entity",f,ifc_class="IfcBuilding",name="BLD-001 Mothership BaseStation")
ifcopenshell.api.run("aggregate.assign_object",f,products=[site],relating_object=project)
ifcopenshell.api.run("aggregate.assign_object",f,products=[bld],relating_object=site)
for i in range(1,5):
    pod=ifcopenshell.api.run("root.create_entity",f,ifc_class="IfcBuilding",name=f"FLT-00{i} Fleet Capsule {i}")
    ifcopenshell.api.run("aggregate.assign_object",f,products=[pod],relating_object=site)
for bname,levels in [("Mothership",["Lower Services","Operations Level","Communications Level"])]+[(f"Fleet {i}",["Service Level","Operations Level"]) for i in range(1,5)]:
    target=bld if bname=="Mothership" else next(x for x in f.by_type("IfcBuilding") if x.Name.startswith(f"FLT-00{bname.split()[-1]}"))
    for lev in levels:
        storey=ifcopenshell.api.run("root.create_entity",f,ifc_class="IfcBuildingStorey",name=f"{bname} - {lev}")
        ifcopenshell.api.run("aggregate.assign_object",f,products=[storey],relating_object=target)
# Spaces and generic component placeholders for coordination
for name in ["Power and UPS Room","Network Distribution Room","Command and Operations","Fleet Monitoring Room","Satellite Terminal Room","GNSS and Antenna Service"]:
    space=ifcopenshell.api.run("root.create_entity",f,ifc_class="IfcSpace",name=name)
    # Attach to first storey as a spatial placeholder
    first=next(x for x in f.by_type("IfcBuildingStorey") if x.Name=="Mothership - Lower Services")
    ifcopenshell.api.run("spatial.assign_container",f,products=[space],relating_structure=first)
f.write(str(out/"mothership_fleet.ifc"))
print("Wrote",out/"mothership_fleet.ifc")
