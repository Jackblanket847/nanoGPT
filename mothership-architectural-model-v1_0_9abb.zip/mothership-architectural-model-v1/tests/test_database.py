import sqlite3, unittest
from pathlib import Path
DB=Path(__file__).resolve().parents[1]/"database"/"mothership_building.sqlite"
class TestModelDatabase(unittest.TestCase):
 def setUp(self): self.c=sqlite3.connect(DB)
 def tearDown(self): self.c.close()
 def test_five_buildings(self):
  self.assertEqual(self.c.execute("select count(*) from buildings").fetchone()[0],5)
 def test_four_capsules(self):
  self.assertEqual(self.c.execute("select count(*) from buildings where building_type='detachable_capsule'").fetchone()[0],4)
 def test_indexes_exist(self):
  names={r[0] for r in self.c.execute("select name from sqlite_master where type='index'")}
  self.assertIn("idx_elements_building",names); self.assertIn("idx_components_element",names)
 def test_component_relationships(self):
  self.assertGreater(self.c.execute("select count(*) from components").fetchone()[0],0)
  self.assertGreater(self.c.execute("select count(*) from connections").fetchone()[0],0)
if __name__=="__main__": unittest.main()
